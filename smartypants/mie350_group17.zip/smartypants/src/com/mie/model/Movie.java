 package com.mie.model;

import java.util.Date;


public class Movie implements Comparable{
	/**
	 * This class contains all of the relevant information, and getter/setter
	 * methods for the Student object.
	 */

	private int RelMovieid;
	private String Title;
	private String Director;
	private Date ReleaseDate;
	private int Metascore;
	private double IMDB;
	private int gore, profanity, action, romance, conflict, comedic, plot, historical, theatrical, fast, suspenseful, sexual; 
	private String posterlink;
	private double Fit;
	private int Score;
	
	public int getScore(){
		return Score;
	}
	
	public void setScore(int Score){
		this.Score = Score;
	}

	public int getMovieID() {
		return RelMovieid;
	}

	public void setMovieid(int movieid) {
		this.RelMovieid = movieid;
	}

	public double getFit() {
		return Fit;
	}

	public void setFit(double fit) {
		Fit = fit;
	}
	
	public String getTitle() {
		return Title;
	}

	public void setTitle(String title) {
		this.Title = title;
	}

	public String getDirector() {
		return Director;
	}

	public void setDirector(String director) {
		this.Director = director;
	}

	public Date getRelDate() {
		return ReleaseDate;
	}

	public void setRelDate(Date date) {
		this.ReleaseDate = date;
	}

	public String getPosterlink() {
		return posterlink;
	}

	public void setPosterlink(String posterlink) {
		this.posterlink = posterlink;
	}

	public int getMeta() {
		return Metascore;
	}

	public void setMeta(int meta) {
		this.Metascore = meta;
	}
	
	public double getIMDB(){
		return IMDB;
	}
	
	public void setIMDB(double imdb){
		this.IMDB = imdb;
	}

	public int getGore() {
		return gore;
	}

	public void setGore(int gore) {
		this.gore = gore;
	}

	public int getProfanity() {
		return profanity;
	}

	public void setProfanity(int profanity) {
		this.profanity = profanity;
	}

	public int getAction() {
		return action;
	}

	public void setAction(int action) {
		this.action = action;
	}

	public int getRomance() {
		return romance;
	}

	public void setRomance(int romance) {
		this.romance = romance;
	}

	public int getConflict() {
		return conflict;
	}

	public void setConflict(int conflict) {
		this.conflict = conflict;
	}

	public int getComedic() {
		return comedic;
	}

	public void setComedic(int comedic) {
		this.comedic = comedic;
	}

	public int getPlot() {
		return plot;
	}

	public void setPlot(int plot) {
		this.plot = plot;
	}

	public int getHistorical() {
		return historical;
	}

	public void setHistorical(int historical) {
		this.historical = historical;
	}

	public int getTheatrical() {
		return theatrical;
	}

	public void setTheatrical(int theatrical) {
		this.theatrical = theatrical;
	}

	public int getFast() {
		return fast;
	}

	public void setFast(int fast) {
		this.fast = fast;
	}

	public int getSuspenseful() {
		return suspenseful;
	}

	public void setSuspenseful(int suspenseful) {
		this.suspenseful = suspenseful;
	}

	public int getSexual() {
		return sexual;
	}

	public void setSexual(int sexual) {
		this.sexual = sexual;
	}
	
	@Override
	public int compareTo(Object compare) {
		Movie temp = (Movie) compare;
		if (this.getFit() < temp.getFit())
			return -1;
		else if (this.getFit() > temp.getFit())
			return 1;
		else
			return 0;

		/* For Descending order do like this */
		// return compareage-this.studentage;
	}
	
	
}