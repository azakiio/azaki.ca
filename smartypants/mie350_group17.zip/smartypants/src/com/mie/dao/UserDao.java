package com.mie.dao;

import java.sql.Connection;
import java.sql.Date;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;

import com.mie.controller.StudentController;
import com.mie.model.Admin;
import com.mie.model.User;
import com.mie.util.DbUtil;

public class UserDao {
	/**
	 * This class handles all of the Student-related methods
	 * (add/update/delete/get).
	 */

	private static Connection connection;

	public UserDao() {
		/**
		 * Get the database connection.
		 */
		connection = DbUtil.getConnection();
	}

	public void addUser(User user) {
		/**
		 * This method adds a new student to the database.
		 */
		try {
			PreparedStatement preparedStatement = connection.prepareStatement("insert into User_Profile(Username,Password,Date_Joined,Curator_Status,First_Name,Last_Name,Date_of_Birth) values (?, ?, ?, ?, ?, ?, ?)");
			// Parameters start with 1
			preparedStatement.setString(1, user.getUsername());
			preparedStatement.setString(2, user.getPassword());
			preparedStatement.setDate(3, new java.sql.Date(user.getDJ().getTime()));
			preparedStatement.setString(4, user.getCurator());
			preparedStatement.setString(5, user.getFirstName());
			preparedStatement.setString(6, user.getLastName());
			preparedStatement.setDate(7, new java.sql.Date(user.getDob().getTime()));
			preparedStatement.executeUpdate();

		} catch (SQLException e) {
			e.printStackTrace();
			StudentController.taken = true;
		}
		if (StudentController.taken != true) {
			try {
				PreparedStatement preparedStatement = connection.prepareStatement("INSERT INTO User_Review (Username,Title) SELECT UP.Username, M.Title FROM Movie AS M, User_Profile AS UP WHERE UP.Username=? ORDER BY Username");
				// Parameters start with 1
				preparedStatement.setString(1, user.getUsername());
				preparedStatement.executeUpdate();
			} catch (SQLException e) {
				e.printStackTrace();
			}
		}
	}

	public void deleteUser(String username) {
		/**
		 * This method deletes a student from the database.
		 */
		try {
			PreparedStatement preparedStatement = connection.prepareStatement("delete from User_Profile where Username=?");
			// Parameters start with 1
			preparedStatement.setString(1, username);
			preparedStatement.executeUpdate();

		} catch (SQLException e) {
			e.printStackTrace();
		}
		try {
			PreparedStatement preparedStatement = connection.prepareStatement("delete from User_Review where Username=?");
			// Parameters start with 1
			preparedStatement.setString(1, username);
			preparedStatement.executeUpdate();

		} catch (SQLException e) {
			e.printStackTrace();
		}
	}

	public void updateUser(User user) {
		/**
		 * This method updates a student's information into the database.
		 */
		try {
			PreparedStatement preparedStatement = connection.prepareStatement("update User Profile set Username=?, Password=?, Date Joined=?, First Name=?, Last Name=?, Date of Birth=?" + " where userid=?");
			// Parameters start with 1
			preparedStatement.setString(1, user.getUsername());
			preparedStatement.setString(2, user.getPassword());
			preparedStatement.setDate(3, new java.sql.Date(user.getDJ().getTime()));
			preparedStatement.setString(4, user.getFirstName());
			preparedStatement.setString(5, user.getLastName());
			preparedStatement.setDate(6, new java.sql.Date(user.getDob().getTime()));
			;
			preparedStatement.setInt(7, user.getUserid());
			preparedStatement.executeUpdate();

		} catch (SQLException e) {
			e.printStackTrace();
		}
	}

	public void Promote(String username) {
		try {
			Statement statement = connection.createStatement();
			System.out.println("Performing Rating Part 1");
			statement.executeUpdate("Update User_Profile set Curator_Status='Yes' where Username=\"" + username + "\"");

		} catch (SQLException e) {
			e.printStackTrace();
		}
	}

	public List<User> getAllUsers() {
		/**
		 * This method returns the list of all students in the form of a List
		 * object.
		 */
		List<User> users = new ArrayList<User>();
		try {
			Statement statement = connection.createStatement();
			System.out.println("getting students from table");
			ResultSet rs = statement.executeQuery("select * from User_Profile order by Curator_Status desc");
			while (rs.next()) {
				User user = new User();
				user.setUsername(rs.getString("Username"));
				user.setPassword(rs.getString("Password"));
				user.setDJ(rs.getDate("Date_Joined"));
				user.setFirstName(rs.getString("First_Name"));
				user.setLastName(rs.getString("Last_Name"));
				user.setDob(rs.getDate("Date_of_Birth"));
				user.setCur(rs.getString("Curator_Status"));
				users.add(user);
			}
		} catch (SQLException e) {
			e.printStackTrace();
		}

		return users;
	}

	public List<User> getUserByKeyword(String keyword) {
		/**
		 * This method retrieves a list of students that matches the keyword
		 * entered by the user.
		 */
		List<User> users = new ArrayList<User>();
		try {
			PreparedStatement preparedStatement = connection.prepareStatement("select * from User_Profile where Username LIKE ? OR First_Name LIKE ? OR Last_Name LIKE ? OR Date_of_Birth LIKE ?");

			preparedStatement.setString(1, "%" + keyword + "%");
			preparedStatement.setString(2, "%" + keyword + "%");
			preparedStatement.setString(3, "%" + keyword + "%");
			preparedStatement.setString(4, "%" + keyword + "%");
			ResultSet rs = preparedStatement.executeQuery();
			while (rs.next()) {
				User user = new User();
				user.setUserid(rs.getInt("userid"));
				user.setUsername(rs.getString("Username"));
				user.setPassword(rs.getString("Password"));
				user.setDJ(rs.getDate("Date_Joined"));
				user.setFirstName(rs.getString("First_Name"));
				user.setLastName(rs.getString("Last_Name"));
				user.setDob(rs.getDate("Date_of_Birth"));
				users.add(user);
			}
		} catch (SQLException e) {
			e.printStackTrace();
		}

		return users;
	}

	public static int checkReview(String username) {

		int answer=-1;
		try {
			PreparedStatement preparedStatement;
			preparedStatement = connection.prepareStatement("SELECT Count(*) AS [Count] FROM User_Review WHERE (((User_Review.Username)=?) AND ((User_Review.score)<>0))");

			preparedStatement.setString(1, username);
			ResultSet count = preparedStatement.executeQuery();
			count.next();
			answer = count.getInt("Count");

		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return answer;

	}
	
	public static String checkStatus(String username) {

		String status = new String();
		try {
			PreparedStatement preparedStatement;
			preparedStatement = connection.prepareStatement("Select * from User_Profile where Username=?");

			preparedStatement.setString(1, username);
			ResultSet stat = preparedStatement.executeQuery();
			stat.next();
			status = stat.getString("Curator_Status");

		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return status;

	}

	public static User login(User user) {

		/**
		 * This method attempts to find the member that is trying to log in by
		 * first retrieving the username and password entered by the user.
		 */
		connection = DbUtil.getConnection();

		String username = user.getUsername();
		String password = user.getPassword();

		/**
		 * Prepare a query that searches the members table in the database with
		 * the given username and password.
		 */
		String searchQuery = "select * from User_Profile where Username='" + username + "' AND Password='" + password + "'";

		try {
			// connect to DB
			Statement stmt = connection.createStatement();
			ResultSet rs = stmt.executeQuery(searchQuery);
			boolean more = rs.next();

			/**
			 * If there are no results from the query, set the member to false.
			 * The person attempting to log in will be redirected to the home
			 * page when isValid is false.
			 */

			if (!more) {
				user.setValid(false);
			}

			/**
			 * If the query results in an database entry that matches the
			 * username and password, assign the appropriate information to the
			 * Member object.
			 */
			else if (more) {
				user.setValid(true);
				user.setFirstName(rs.getString("First_Name"));
				user.setLastName(rs.getString("Last_Name"));
				user.setCur(rs.getString("Curator_Status"));

				try {
					PreparedStatement preparedStatement = connection.prepareStatement("SELECT Count(*) AS [Count] FROM User_Review WHERE (((User_Review.Username)=?) AND ((User_Review.score)<>0))");
					preparedStatement.setString(1, username);
					ResultSet count = preparedStatement.executeQuery();

					if (count.next()) {
						user.setReviewCount(count.getInt("Count"));

					}
				} catch (SQLException e) {
					e.printStackTrace();
				}

			}
		}

		catch (Exception ex) {
			System.out.println("Log In failed: An Exception has occurred! " + ex);
			ex.printStackTrace();
		}
		/**
		 * Return the Member object.
		 */
		return user;

	}

}