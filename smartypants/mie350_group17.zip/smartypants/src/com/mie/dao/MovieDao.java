package com.mie.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.*;

import com.mie.model.Movie;
import com.mie.util.DbUtil;

public class MovieDao {
	/**
	 * This class handles all of the Student-related methods
	 * (add/update/delete/get).
	 */

	private Connection connection;

	public MovieDao() {
		/**
		 * Get the database connection.
		 */
		connection = DbUtil.getConnection();
	}

	public void addMovie(Movie movie) {
		/**
		 * This method adds a new student to the database.
		 */
		try {
			PreparedStatement preparedStatement = connection.prepareStatement("insert into Pending_Movie (Title, Director, Release_Date, Metascore, IMDb_Score, Gore, Profanity, Action, Romance, Conflict, Comedic, Plot, Historical, Theatrical, Fast, Suspenseful, Sexual) values (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)");
			preparedStatement.setString(1, movie.getTitle());
			preparedStatement.setString(2, movie.getDirector());
			preparedStatement.setDate(3, new java.sql.Date(movie.getRelDate().getTime()));
			preparedStatement.setInt(4, movie.getMeta());
			preparedStatement.setDouble(5, movie.getIMDB());
			preparedStatement.setInt(6, movie.getGore());
			preparedStatement.setInt(7, movie.getProfanity());
			preparedStatement.setInt(8, movie.getAction());
			preparedStatement.setInt(9, movie.getRomance());
			preparedStatement.setInt(10, movie.getConflict());
			preparedStatement.setInt(11, movie.getComedic());
			preparedStatement.setInt(12, movie.getPlot());
			preparedStatement.setInt(13, movie.getHistorical());
			preparedStatement.setInt(14, movie.getTheatrical());
			preparedStatement.setInt(15, movie.getFast());
			preparedStatement.setInt(16, movie.getSuspenseful());
			preparedStatement.setInt(17, movie.getSexual());
			preparedStatement.executeUpdate();
			
			System.out.println("yaaaaaaaaaaaaaaaaaaaaaw");
			
		} catch (SQLException e) {
			e.printStackTrace();
		}
	}

	public void UnRateMovie(String username, Movie movie, int score) {
		/**
		 * This method updates a student's information into the database.
		 */
		String[] list = new String[24];
		list[0] = "Gore_" + movie.getGore() + " = Gore_" + movie.getGore() + " - " + score;
		list[1] = "Profanity_" + movie.getProfanity() + " = Profanity_" + movie.getProfanity() + " - " + score;
		list[2] = "Action_" + movie.getAction() + " = Action_" + movie.getAction() + " - " + score;
		list[3] = "Romance_" + movie.getRomance() + " = Romance_" + movie.getRomance() + " - " + score;
		list[4] = "Conflict_" + movie.getConflict() + " = Conflict_" + movie.getConflict() + " - " + score;
		list[5] = "Comedic_" + movie.getComedic() + " = Comedic_" + movie.getComedic() + " - " + score;
		list[6] = "Plot_" + movie.getPlot() + " = Plot_" + movie.getPlot() + " - " + score;
		list[7] = "Historical_" + movie.getHistorical() + " = Historical_" + movie.getHistorical() + " - " + score;
		list[8] = "Theatrical_" + movie.getTheatrical() + " = Theatrical_" + movie.getTheatrical() + " - " + score;
		list[9] = "Fast_" + movie.getFast() + " = Fast_" + movie.getFast() + " - " + score;
		list[10] = "Suspenseful_" + movie.getSuspenseful() + " = Suspenseful_" + movie.getSuspenseful() + " - " + score;
		list[11] = "Sexual_" + movie.getSexual() + " = Sexual_" + movie.getSexual() + " - " + score;

		list[12] = "Count_Gore_" + movie.getGore() + " = Count_Gore_" + movie.getGore() + " - 1";
		list[13] = "Count_Profanity_" + movie.getProfanity() + " = Count_Profanity_" + movie.getProfanity() + " - 1";
		list[14] = "Count_Action_" + movie.getAction() + " = Count_Action_" + movie.getAction() + " - 1";
		list[15] = "Count_Romance_" + movie.getRomance() + " = Count_Romance_" + movie.getRomance() + " - 1";
		list[16] = "Count_Conflict_" + movie.getConflict() + " = Count_Conflict_" + movie.getConflict() + " - 1";
		list[17] = "Count_Comedic_" + movie.getComedic() + " = Count_Comedic_" + movie.getComedic() + " - 1";
		list[18] = "Count_Plot_" + movie.getPlot() + " = Count_Plot_" + movie.getPlot() + " - 1";
		list[19] = "Count_Historical_" + movie.getHistorical() + " = Count_Historical_" + movie.getHistorical() + " - 1";
		list[20] = "Count_Theatrical_" + movie.getTheatrical() + " = Count_Theatrical_" + movie.getTheatrical() + " - 1";
		list[21] = "Count_Fast_" + movie.getFast() + " = Count_Fast_" + movie.getFast() + " - 1";
		list[22] = "Count_Suspenseful_" + movie.getSuspenseful() + " = Count_Suspenseful_" + movie.getSuspenseful() + " - 1";
		list[23] = "Count_Sexual_" + movie.getSexual() + " = Count_Sexual_" + movie.getSexual() + " - 1";

		StringBuilder sb = new StringBuilder();
		sb.append(list[0]);
		for (int i = 1; i < list.length; i++) {
			sb.append(", ");
			sb.append(list[i]);
		}
		String query = sb.toString();

		try {
			Statement statement = connection.createStatement();
			statement.executeUpdate("Update User_Profile set " + query + " where Username=\"" + username + "\"");

		} catch (SQLException e) {
			e.printStackTrace();
		}

		try {

			PreparedStatement preparedStatement = connection.prepareStatement("Update User_Review set Score=? WHERE Username=? AND Title=?");
			// Parameters start with 1
			preparedStatement.setInt(1, 0);
			preparedStatement.setString(2, username);
			preparedStatement.setString(3, movie.getTitle());
			preparedStatement.executeUpdate();
			System.out.print(movie.getTitle());

		} catch (SQLException e) {
			e.printStackTrace();
		}
	}

	public List<Movie> getAllMovies() {
		/**
		 * This method returns the list of all students in the form of a List
		 * object.
		 */
		List<Movie> movies = new ArrayList<Movie>();
		try {
			Statement statement = connection.createStatement();
			System.out.println("getting students from table");
			ResultSet rs = statement.executeQuery("select * from Movie order by Title asc");
			while (rs.next()) {
				Movie movie = new Movie();
				movie.setTitle(rs.getString("Title"));
				movie.setDirector(rs.getString("Director"));
				movie.setRelDate(rs.getDate("Release_Date"));
				movie.setMeta(rs.getInt("Metascore"));
				movie.setIMDB(rs.getInt("IMDb_Score"));
				movies.add(movie);
			}
		} catch (SQLException e) {
			e.printStackTrace();
		}

		return movies;
	}

	public List<Movie> getRatedMovies(String username) {
		/**
		 * This method returns the list of all students in the form of a List
		 * object.
		 */
		List<Movie> movies = new ArrayList<Movie>();
		try {
			Statement statement = connection.createStatement();
			System.out.println("getting rated movies from table");
			ResultSet rs = statement.executeQuery("select * from User_Review Where Username=\"" + username + "\" and Score<>0 order by Score desc");
			while (rs.next()) {
				Movie movie = new Movie();
				movie.setTitle(rs.getString("Title"));
				movie.setScore(rs.getInt("Score"));

				movies.add(movie);
			}
		} catch (SQLException e) {
			e.printStackTrace();
		}

		return movies;
	}

	public List<Movie> getUnratedMovies(String username) {
		/**
		 * This method returns the list of all students in the form of a List
		 * object.
		 */
		List<Movie> movies = new ArrayList<Movie>();
		try {
			Statement statement = connection.createStatement();
			System.out.println("getting rated movies from table");
			ResultSet rs = statement.executeQuery("select * from User_Review Where Username=\"" + username + "\" and Score=0 order by Title asc");
			while (rs.next()) {
				Movie movie = new Movie();
				movie.setTitle(rs.getString("Title"));
				movie.setMeta(rs.getInt("Fit"));

				movies.add(movie);
			}
		} catch (SQLException e) {
			e.printStackTrace();
		}

		return movies;
	}

	public void RateMovie(String username, Movie movie, int rating) {
		/**
		 * This method updates a student's information into the database.
		 */
		String[] list = new String[24];
		list[0] = "Gore_" + movie.getGore() + " = Gore_" + movie.getGore() + " + " + rating;
		list[1] = "Profanity_" + movie.getProfanity() + " = Profanity_" + movie.getProfanity() + " + " + rating;
		list[2] = "Action_" + movie.getAction() + " = Action_" + movie.getAction() + " + " + rating;
		list[3] = "Romance_" + movie.getRomance() + " = Romance_" + movie.getRomance() + " + " + rating;
		list[4] = "Conflict_" + movie.getConflict() + " = Conflict_" + movie.getConflict() + " + " + rating;
		list[5] = "Comedic_" + movie.getComedic() + " = Comedic_" + movie.getComedic() + " + " + rating;
		list[6] = "Plot_" + movie.getPlot() + " = Plot_" + movie.getPlot() + " + " + rating;
		list[7] = "Historical_" + movie.getHistorical() + " = Historical_" + movie.getHistorical() + " + " + rating;
		list[8] = "Theatrical_" + movie.getTheatrical() + " = Theatrical_" + movie.getTheatrical() + " + " + rating;
		list[9] = "Fast_" + movie.getFast() + " = Fast_" + movie.getFast() + " + " + rating;
		list[10] = "Suspenseful_" + movie.getSuspenseful() + " = Suspenseful_" + movie.getSuspenseful() + " + " + rating;
		list[11] = "Sexual_" + movie.getSexual() + " = Sexual_" + movie.getSexual() + " + " + rating;

		list[12] = "Count_Gore_" + movie.getGore() + " = Count_Gore_" + movie.getGore() + " + 1";
		list[13] = "Count_Profanity_" + movie.getProfanity() + " = Count_Profanity_" + movie.getProfanity() + " + 1";
		list[14] = "Count_Action_" + movie.getAction() + " = Count_Action_" + movie.getAction() + " + 1";
		list[15] = "Count_Romance_" + movie.getRomance() + " = Count_Romance_" + movie.getRomance() + " + 1";
		list[16] = "Count_Conflict_" + movie.getConflict() + " = Count_Conflict_" + movie.getConflict() + " + 1";
		list[17] = "Count_Comedic_" + movie.getComedic() + " = Count_Comedic_" + movie.getComedic() + " + 1";
		list[18] = "Count_Plot_" + movie.getPlot() + " = Count_Plot_" + movie.getPlot() + " + 1";
		list[19] = "Count_Historical_" + movie.getHistorical() + " = Count_Historical_" + movie.getHistorical() + " + 1";
		list[20] = "Count_Theatrical_" + movie.getTheatrical() + " = Count_Theatrical_" + movie.getTheatrical() + " + 1";
		list[21] = "Count_Fast_" + movie.getFast() + " = Count_Fast_" + movie.getFast() + " + 1";
		list[22] = "Count_Suspenseful_" + movie.getSuspenseful() + " = Count_Suspenseful_" + movie.getSuspenseful() + " + 1";
		list[23] = "Count_Sexual_" + movie.getSexual() + " = Count_Sexual_" + movie.getSexual() + " + 1";

		StringBuilder sb = new StringBuilder();
		sb.append(list[0]);
		for (int i = 1; i < list.length; i++) {
			sb.append(", ");
			sb.append(list[i]);
		}
		String query = sb.toString();

		try {
			Statement statement = connection.createStatement();
			System.out.println("Performing Rating Part 1");
			statement.executeUpdate("Update User_Profile set " + query + " where Username=\"" + username + "\"");

		} catch (SQLException e) {
			e.printStackTrace();
		}

		try {

			PreparedStatement preparedStatement = connection.prepareStatement("Update User_Review set Score=? WHERE Username=? AND Title=?");
			// Parameters start with 1
			preparedStatement.setInt(1, rating);
			preparedStatement.setString(2, username);
			preparedStatement.setString(3, movie.getTitle());
			preparedStatement.executeUpdate();
			System.out.print(movie.getTitle());

		} catch (SQLException e) {
			e.printStackTrace();
		}

	}

	public List<Movie> calcFit(String username) {
		/**
		 * This method returns the list of all students in the form of a List
		 * object.
		 */
		List<Movie> movies = new ArrayList<Movie>();
		double fit;
		int[] results = new int[24];

		try {
			Statement statement1 = connection.createStatement();
			System.out.println("getting rated movies from table");
			ResultSet rs1 = statement1.executeQuery("select * from User_Profile where Username=\"" + username + "\"");
			rs1.next();
			Statement statement = connection.createStatement();
			System.out.println("getting rated movies from table");
			ResultSet rs = statement.executeQuery("select * from Movie order by Title asc");
			while (rs.next()) {
				fit = 0;
				Movie movie = new Movie();
				movie.setTitle(rs.getString("Title"));
				movie.setDirector(rs.getString("Director"));
				movie.setRelDate(rs.getDate("Release_Date"));
				movie.setMeta(rs.getInt("Metascore"));
				movie.setIMDB(rs.getDouble("IMDb_Score"));
				movie.setPosterlink(rs.getString("Poster"));
				movie.setGore(rs.getInt("Gore"));
				movie.setProfanity(rs.getInt("Profanity"));
				movie.setAction(rs.getInt("Action"));
				movie.setRomance(rs.getInt("Romance"));
				movie.setConflict(rs.getInt("Conflict"));
				movie.setComedic(rs.getInt("Comedic"));
				movie.setPlot(rs.getInt("Plot"));
				movie.setHistorical(rs.getInt("Historical"));
				movie.setTheatrical(rs.getInt("Theatrical"));
				movie.setFast(rs.getInt("Fast"));
				movie.setSuspenseful(rs.getInt("Suspenseful"));
				movie.setSexual(rs.getInt("Sexual"));

				results[0] = rs1.getInt("Gore_" + movie.getGore());
				results[1] = rs1.getInt("Count_Gore_" + movie.getGore());
				results[2] = rs1.getInt("Profanity_" + movie.getProfanity());
				results[3] = rs1.getInt("Count_Profanity_" + movie.getProfanity());
				results[4] = rs1.getInt("Action_" + movie.getAction());
				results[5] = rs1.getInt("Count_Action_" + movie.getAction());
				results[6] = rs1.getInt("Romance_" + movie.getRomance());
				results[7] = rs1.getInt("Count_Romance_" + movie.getRomance());
				results[8] = rs1.getInt("Conflict_" + movie.getConflict());
				results[9] = rs1.getInt("Count_Conflict_" + movie.getConflict());
				results[10] = rs1.getInt("Comedic_" + movie.getComedic());
				results[11] = rs1.getInt("Count_Comedic_" + movie.getComedic());
				results[12] = rs1.getInt("Plot_" + movie.getPlot());
				results[13] = rs1.getInt("Count_Plot_" + movie.getPlot());
				results[14] = rs1.getInt("Historical_" + movie.getHistorical());
				results[15] = rs1.getInt("Count_Historical_" + movie.getHistorical());
				results[16] = rs1.getInt("Theatrical_" + movie.getTheatrical());
				results[17] = rs1.getInt("Count_Theatrical_" + movie.getTheatrical());
				results[18] = rs1.getInt("Fast_" + movie.getFast());
				results[19] = rs1.getInt("Count_Fast_" + movie.getFast());
				results[20] = rs1.getInt("Suspenseful_" + movie.getSuspenseful());
				results[21] = rs1.getInt("Count_Suspenseful_" + movie.getSuspenseful());
				results[22] = rs1.getInt("Sexual_" + movie.getSexual());
				results[23] = rs1.getInt("Count_Sexual_" + movie.getSexual());

				for (int i = 0; i < results.length - 1; i += 2) {
					if (results[i] != 0)
						fit += (double) (results[i] / results[i + 1]);
				}
				movie.setFit(fit);

				movies.add(movie);
			}

		} catch (SQLException e) {
			e.printStackTrace();
		}

		return movies;
	}

	public List<Movie> getBest(String username, List<Movie> movies) {
		/**
		 * This method returns the list of all students in the form of a List
		 * object.
		 */
		List<Movie> top5 = new ArrayList<Movie>();
		try {

			Statement statement = connection.createStatement();
			System.out.println("getting students from table");
			ResultSet rs = statement.executeQuery("select * from User_Review where Score=0 AND Username=\"" + username + "\"");
			while (rs.next()) {
				for (Movie m : movies) {
					if (m.getTitle().equals(rs.getString("Title")))
						top5.add(m);

				}
			}

		} catch (SQLException e) {
			e.printStackTrace();
		}
		Collections.sort(top5);
		top5.subList(5, top5.size()).clear();
		return top5;
	}

	public Movie getMovieByTitle(String title) {
		/**
		 * This method retrieves a student by their StudentID number.
		 * 
		 * Currently not used in the sample web app, but code is left here for
		 * your review.
		 */
		Movie movie = new Movie();
		try {
			PreparedStatement preparedStatement = connection.prepareStatement("select * from Movie where Title=?");
			preparedStatement.setString(1, title);
			ResultSet rs = preparedStatement.executeQuery();

			if (rs.next()) {
				movie.setTitle(title);
				movie.setGore(rs.getInt("Gore"));
				movie.setProfanity(rs.getInt("Profanity"));
				movie.setAction(rs.getInt("Action"));
				movie.setRomance(rs.getInt("Romance"));
				movie.setConflict(rs.getInt("Conflict"));
				movie.setComedic(rs.getInt("Comedic"));
				movie.setPlot(rs.getInt("Plot"));
				movie.setHistorical(rs.getInt("Historical"));
				movie.setTheatrical(rs.getInt("Theatrical"));
				movie.setFast(rs.getInt("Fast"));
				movie.setSuspenseful(rs.getInt("Suspenseful"));
				movie.setSexual(rs.getInt("Sexual"));
			}
		} catch (SQLException e) {
			e.printStackTrace();
		}

		return movie;
	}



}