package com.mie.controller;

import java.io.IOException;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.mie.dao.MovieDao;
import com.mie.dao.UserDao;
import com.mie.model.Movie;
import com.mie.model.User;

public class StudentController extends HttpServlet {
	/**
	 * This class handles all insert/edit/list functions of the servlet.
	 * 
	 * These are variables that lead to the appropriate JSP pages. INSERT leads
	 * to the Add A Student page. EDIT leads to the Edit A Student page.
	 * LIST_STUDENT_PUBLIC leads to the public listing of students.
	 * LIST_STUDENT_ADMIN leads to the admin-only listing of students (for them
	 * to modify student information).
	 * 
	 */
	private static final long serialVersionUID = 1L;
	private static String INSERT = "/addUser.jsp";
	private static String EDIT = "/editStudent.jsp";
	private static String LIST_STUDENT_PUBLIC = "/listStudentPublic.jsp";
	private static String LIST_STUDENT_ADMIN = "/listUsers.jsp";
	public static boolean taken;
	private UserDao dao;

	/**
	 * Constructor for this class.
	 */
	public StudentController() {
		super();
		dao = new UserDao();
	}

	protected void doGet(HttpServletRequest request,
			HttpServletResponse response) throws ServletException, IOException {

		/**
		 * This class retrieves the appropriate 'action' found on the JSP pages:
		 * 
		 * - delete will direct the servlet to let the user delete a student in
		 * the database. - insert will direct the servlet to let the user add a
		 * new student to the database. - edit will direct the servlet to let
		 * the user edit student information in the database. - listStudent will
		 * direct the servlet to the public listing of all students in the
		 * database. - listStudentAdmin will direct the servlet to the admin
		 * listing of all students in the database.
		 */
		String forward = "";
		String action = request.getParameter("action");

		if (action.equalsIgnoreCase("delete")) {
			String username = request.getParameter("username");
			dao.deleteUser(username);
			forward = LIST_STUDENT_ADMIN;
			request.setAttribute("users", dao.getAllUsers());
		} else if (action.equalsIgnoreCase("insert")) {
			forward = INSERT;
		} else if (action.equalsIgnoreCase("promote")) {
			String username = request.getParameter("username");
			dao.Promote(username);
			forward= LIST_STUDENT_ADMIN;
			request.setAttribute("users", dao.getAllUsers());
		} else if (action.equalsIgnoreCase("listStudent")) {
			forward = LIST_STUDENT_PUBLIC;
			request.setAttribute("users", dao.getAllUsers());
		} else if (action.equalsIgnoreCase("listStudentAdmin")) {
			forward = LIST_STUDENT_ADMIN;
			request.setAttribute("users", dao.getAllUsers());
		} else {
			forward = INSERT;
		}

		RequestDispatcher view = request.getRequestDispatcher(forward);
		view.forward(request, response);
	}

	protected void doPost(HttpServletRequest request,
			HttpServletResponse response) throws ServletException, IOException {

		/**
		 * This method retrieves all of the information entered in the form on
		 * the addStudent.jsp or the editStudent.jsp pages.
		 */
		User user = new User();
		user.setFirstName(request.getParameter("First_Name"));
		user.setLastName(request.getParameter("Last_Name"));
		user.setUsername(request.getParameter("Username"));
		user.setPassword(request.getParameter("Password"));
		try {
			Date DJ = new SimpleDateFormat("MM/dd/yyyy").parse(request
					.getParameter("Date_Joined"));
			user.setDJ(DJ);
		} catch (ParseException e) {
			e.printStackTrace();
		}
		try {
			Date dob = new SimpleDateFormat("MM/dd/yyyy").parse(request
					.getParameter("Date_of_Birth"));
			user.setDob(dob);
		} catch (ParseException e) {
			e.printStackTrace();
		}
		user.setCur(request.getParameter("curator"));
		String UserID = request.getParameter("Userid");
		/**
		 * If the 'studentid' field in the form is empty, the new student will
		 * be added to the list of Student objects.
		 */
		if (UserID == null || UserID.isEmpty()) {
			taken=false;
			dao.addUser(user);
		} 
		if(taken==true)
			response.sendRedirect("usernameTaken.jsp");
		else
			response.sendRedirect("accountcreated.jsp");
	}
}